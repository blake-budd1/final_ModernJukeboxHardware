import json

def create_spotify_credentials():
    # prompt user to enter spotify developer credentials needed
    print("Please Enter Spotify Developer Credentials Below.")
    print("Enter Device Id:")
    DEVICE_ID = input()
    print("Enter Client Id:")
    CLIENT_ID = input()
    print("Enter Client Secret:")
    CLIENT_SECRET = input()

    #create json file
    authentication_dict = {
        "DEVICE_ID": DEVICE_ID,
        "CLIENT_ID": CLIENT_ID,
        "CLIENT_SECRET": CLIENT_SECRET,
    }

    with open("../spotify.json", "w") as fs:
        json.dump(authentication_dict, fs)

create_spotify_credentials()
